<script setup lang="ts">
</script>

<template>
  <Suspense>
    <RouterView />
  </Suspense>
</template>

<style></style>
